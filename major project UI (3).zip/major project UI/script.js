// Switch between login and register forms
function showLogin() {
    document.getElementById("loginForm").style.display = "block";
    document.getElementById("registerForm").style.display = "none";
}

function showRegister() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("registerForm").style.display = "block";
}

// Login function with proper form submission handling
function login(event) {
    event.preventDefault();
    let email = document.getElementById("loginEmail").value;
    let password = document.getElementById("loginPassword").value;
    
    if(email && password) {
        alert("Logged in successfully!");
        window.location.href = 'main.html';  // Redirect to main page
    } else {
        alert("Please enter valid credentials");
    }
}

// Register function with proper form submission handling
function register(event) {
    event.preventDefault();
    let name = document.getElementById("registerName").value;
    let email = document.getElementById("registerEmail").value;
    let password = document.getElementById("registerPassword").value;

    if(name && email && password) {
        // Save user data in localStorage
        localStorage.setItem('userName', name);
        localStorage.setItem('userEmail', email);
        alert("Registration successful!");
        showLogin();  // Switch to login form after registration
    } else {
        alert("Please fill all fields");
    }
}

// Search functionality (Placeholder)
function searchItem() {
    let searchQuery = document.getElementById("searchInput").value;
    let resultsContainer = document.getElementById("resultsContainer");
    
    if(searchQuery) {
        resultsContainer.innerHTML = `<p>Searching for best deals on: <strong>${searchQuery}</strong></p>`;
        // Simulate fetching from APIs
        resultsContainer.innerHTML += `<p>Fetching results from Amazon, Flipkart, Myntra, and Meesho...</p>`;
    } else {
        alert("Please enter an item to search.");
    }
}

// Show profile modal and fill in user details
// Assuming you get the user's name and email from login
 let name = document.getElementById("registerName").value;
let email = document.getElementById("registerEmail").value;

// Function to display the user's profile information
function showProfile() {
    document.getElementById("profileName").innerText = userName;
    document.getElementById("profileEmail").innerText = userEmail;

    // Show the profile modal
    document.getElementById("profileModal").style.display = "block";
}

// Function to close the profile modal
function closeProfile() {
    document.getElementById("profileModal").style.display = "none";
}

// Set the profile name in the header after login
document.getElementById("profileNameDisplay").innerText = userName;


// Search functionality to show results with images
// Search functionality to show results with filters
// Search functionality with combined filters
function searchItem() {
    let searchQuery = document.getElementById("searchInput").value.toLowerCase();
    let combinedFilter = document.getElementById("combinedFilter").value;
    
    let resultsContainer = document.getElementById("resultsContainer");
    
    // Placeholder data to simulate results
    let products = [
        { name: 'Running Shoes', size: 'Medium', color: 'Black', image: 'https://via.placeholder.com/150?text=Running+Shoes' },
        { name: 'Sneakers', size: 'Large', color: 'White', image: 'https://via.placeholder.com/150?text=Sneakers' },
        { name: 'Formal Shoes', size: 'Small', color: 'Black', image: 'https://via.placeholder.com/150?text=Formal+Shoes' },
        { name: 'Basketball Shoes', size: 'Medium', color: 'Red', image: 'https://via.placeholder.com/150?text=Basketball+Shoes' },
        { name: 'Casual Shoes', size: 'Large', color: 'White', image: 'https://via.placeholder.com/150?text=Casual+Shoes' }
    ];

    if (searchQuery) {
        // Clear previous results
        resultsContainer.innerHTML = `<p>Showing results for: <strong>${searchQuery}</strong></p>`;
        
        // Parse the combined filter
        let filterKey = combinedFilter.split(':')[0];
        let filterValue = combinedFilter.split(':')[1]?.toLowerCase();

        // Filter products by search query and combined filter
        let filteredProducts = products.filter(product =>
            product.name.toLowerCase().includes(searchQuery) &&
            (filterKey === "name" && filterValue ? product.name.toLowerCase().includes(filterValue) : true) &&
            (filterKey === "size" && filterValue ? product.size.toLowerCase() === filterValue : true) &&
            (filterKey === "color" && filterValue ? product.color.toLowerCase() === filterValue : true)
        );

        // Display filtered products
        if (filteredProducts.length > 0) {
            filteredProducts.forEach(product => {
                resultsContainer.innerHTML += `
                    <div class="product">
                        <img src="${product.image}" alt="${product.name}" />
                        <p>${product.name}</p>
                        <p>Size: ${product.size}</p>
                        <p>Color: ${product.color}</p>
                    </div>
                `;
            });
        } else {
            resultsContainer.innerHTML += `<p>No results found.</p>`;
        }
    } else {
        alert("Please enter an item to search.");
    }
}
